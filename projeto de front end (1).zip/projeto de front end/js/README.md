# Projeto 3 - Painel Interativo

**Tema:** DevPath | Descubra seu Caminho no Front-End  
**Disciplina:** Desenvolvimento Front-End para Web  
**Instituição:** Universidade Cruzeiro do Sul  

## Integrantes do Grupo
* **Ana Carolina Rufino Costa dos Santos** — RGM: 049765051
* **Gustavo Fernandes do Nascimento** — RGM: 49975897
* **Gustavo Ramos da Silva** — RGM: 04976377-6

## Divisão das Tarefas
* **Ana Carolina Rufino Costa dos Santos:** Estruturação semântica em HTML, controles de acessibilidade (ajuste de fonte, navegação por teclado e atributos ARIA) e integração geral dos arquivos.
* **Gustavo Fernandes do Nascimento:** Identidade visual em CSS externo, layout responsivo com Grid/Flexbox, estados de interação (`:hover`) e alternância entre temas claro e escuro.
* **Gustavo Ramos da Silva:** Programação em JavaScript externo (tela de acesso, validação de campos, lógica condicional com `switch`, manipulação do DOM e documentação).

## Explicação Breve do Funcionamento
Ao acessar a página, o visitante passa por uma tela de identificação onde informa seu nome, telefone (com máscara automática) e e-mail opcional. Após validar os dados, o portal **DevPath** é desbloqueado, apresentando informações sobre o mercado Front-End, a trilha de tecnologias (HTML, CSS e JavaScript) e o painel interativo.

No painel interativo, o visitante confirma seu nome, escolhe sua área de interesse e clica em **Gerar orientação**. O JavaScript valida o campo, seleciona as recomendações específicas usando `switch` e exibe na própria página a orientação personalizada, insights de mercado, sugestão de projeto prático e um botão com link direto para a documentação oficial da MDN Web Docs. No cabeçalho, botões permitem ajustar o tamanho da fonte e alternar entre os temas escuro e claro.

## Comandos JavaScript Utilizados
* `document.getElementById()`: Localiza e armazena referências dos inputs, selects, botões e áreas de resultado do HTML.
* `const` e `let`: Declara variáveis constantes para elementos do DOM e variáveis mutáveis para mensagens e textos dinâmicos.
* `addEventListener('click', ...)` e `addEventListener('input', ...)`: Executa ações ao clicar nos botões (entrar, gerar orientação, trocar tema e alterar fonte) e formata o telefone durante a digitação.
* `.value` e `.trim()`: Captura o texto digitado nos campos e remove espaços vazios nas extremidades antes da validação.
* `if/else` e `switch`: Valida o preenchimento obrigatório dos campos e define as orientações, projetos e links específicos para HTML, CSS e JavaScript.
* `Template string`: Insere variáveis dentro das strings de resposta (ex.: `` `Olá, ${nome}! Trilha confirmada 🚀` ``).
* `.textContent`: Atualiza o conteúdo textual dos elementos na própria página com segurança, sem depender apenas de `alert()`.
* `.classList.toggle()`, `.classList.add()` e `.classList.remove()`: Alterna a classe `.tema-escuro` no `body` e controla a exibição das telas e mensagens de erro/sucesso.

## Captura de Tela
*(Insira aqui o print da página funcionando antes de gerar o arquivo ZIP para entrega no Blackboard)*