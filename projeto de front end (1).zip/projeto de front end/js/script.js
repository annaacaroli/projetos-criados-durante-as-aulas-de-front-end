// ELEMENTOS DA TELA DE LOGIN
const telaLogin = document.getElementById('tela-login');
const siteCompleto = document.getElementById('site-completo');
const loginNome = document.getElementById('login-nome');
const loginTelefone = document.getElementById('login-telefone');
const loginEmail = document.getElementById('login-email');
const btnEntrar = document.getElementById('btn-entrar');
const erroLogin = document.getElementById('erro-login');
const usuarioLogado = document.getElementById('usuario-logado');

// ELEMENTOS DO PAINEL INTERATIVO
const inputNome = document.getElementById('nome');
const selectInteresse = document.getElementById('interesse');
const btnGerar = document.getElementById('btn-gerar');
const btnTema = document.getElementById('btn-tema');

const areaResultado = document.getElementById('area-resultado');
const saudacaoResultado = document.getElementById('saudacao-resultado');
const mensagemResultado = document.getElementById('mensagem-resultado');
const dicaPratica = document.getElementById('dica-pratica');
const projetoSugerido = document.getElementById('projeto-sugerido');
const linkEstudo = document.getElementById('link-estudo');

const btnAumentarFonte = document.getElementById('btn-aumentar-fonte');
const btnDiminuirFonte = document.getElementById('btn-diminuir-fonte');
const htmlRoot = document.documentElement;
let tamanhoFonteAtual = 16;

// Máscara automática para o telefone no login
loginTelefone.addEventListener('input', (e) => {
    let valor = e.target.value.replace(/\D/g, '');
    if (valor.length > 11) valor = valor.slice(0, 11);
    if (valor.length > 2) {
        valor = `(${valor.slice(0, 2)}) ${valor.slice(2)}`;
    }
    if (valor.length > 10) {
        valor = `${valor.slice(0, 10)}-${valor.slice(10)}`;
    }
    e.target.value = valor;
});

// Validação e acesso pelo Login
btnEntrar.addEventListener('click', () => {
    const nomeDigitado = loginNome.value.trim();
    const telefoneDigitado = loginTelefone.value.trim();
    const emailDigitado = loginEmail.value.trim();

    erroLogin.classList.add('oculto');

    if (nomeDigitado === '') {
        erroLogin.textContent = 'Por favor, informe o seu nome completo para entrar.';
        erroLogin.classList.remove('oculto');
        loginNome.focus();
        return;
    }

    if (telefoneDigitado.replace(/\D/g, '').length < 10) {
        erroLogin.textContent = 'Por favor, informe um telefone válido com DDD.';
        erroLogin.classList.remove('oculto');
        loginTelefone.focus();
        return;
    }

    if (emailDigitado !== '' && (!emailDigitado.includes('@') || !emailDigitado.includes('.'))) {
        erroLogin.textContent = 'O e-mail informado não parece válido. Corrija ou deixe em branco.';
        erroLogin.classList.remove('oculto');
        loginEmail.focus();
        return;
    }

    // Libera o site e preenche automaticamente o nome do visitante
    telaLogin.classList.add('oculto');
    siteCompleto.classList.remove('oculto');
    usuarioLogado.textContent = `👤 Olá, ${nomeDigitado.split(' ')[0]}`;
    inputNome.value = nomeDigitado;
});

// Evento disparado ao clicar no botão gerar orientação
btnGerar.addEventListener('click', () => {
    const nome = inputNome.value.trim();
    const interesse = selectInteresse.value;

    areaResultado.classList.remove('oculto', 'erro', 'sucesso');
    linkEstudo.classList.add('oculto'); 

    if (nome === "") {
        saudacaoResultado.textContent = "Atenção: Nome Incompleto!";
        mensagemResultado.textContent = "Por favor, preencha o seu nome no campo acima para gerar sua orientação.";
        dicaPratica.textContent = "Campos validados evitam erros na experiência do usuário.";
        projetoSugerido.textContent = "Aguardando preenchimento do formulário...";
        
        areaResultado.classList.add('erro');
        inputNome.focus();
        return; 
    }

    let orientacao = "";
    let textoDica = "";
    let textoProjeto = "";
    let urlReferencia = "";
    let textoLink = "";
    let corDestaqueLink = "";

    // Documentações oficiais sem números de versão nos títulos
    switch (interesse) {
        case 'html':
            orientacao = "Você escolheu começar pelo alicerce. Empresas buscam desenvolvedores que entendem de SEO e Acessibilidade (WCAG) desde o código HTML.";
            textoDica = "Entenda a semântica. Uma página estruturada com <header>, <main>, <article> e <nav> melhora o ranqueamento e a leitura por tecnologias assistivas.";
            textoProjeto = "Desenvolva uma Landing Page institucional contendo formulário de contato acessível, tabela comparativa e navegação semântica.";
            urlReferencia = "https://developer.mozilla.org/pt-BR/docs/Web/HTML";
            textoLink = "🟧 Documentação Oficial HTML (MDN Web Docs)";
            corDestaqueLink = "#e34c26";
            break;

        case 'css':
            orientacao = "A engenharia visual! Dominar o CSS moderno é o que diferencia um iniciante de um desenvolvedor capaz de criar interfaces profissionais.";
            textoDica = "Domine CSS Flexbox e CSS Grid Layout, além de variáveis nativas (--var) e Media Queries para responsividade Mobile-First.";
            textoProjeto = "Crie um Dashboard responsivo com tema claro/escuro, barra lateral fixa e cartões de métricas que se adaptam ao celular.";
            urlReferencia = "https://developer.mozilla.org/pt-BR/docs/Web/CSS";
            textoLink = "🟦 Documentação Oficial CSS (MDN Web Docs)";
            corDestaqueLink = "#264de4";
            break;

        case 'js':
            orientacao = "O núcleo da interatividade Front-End. O JavaScript controla a manipulação do DOM, eventos e a comunicação assíncrona com APIs.";
            textoDica = "Domine manipulação de DOM, eventos, métodos modernos de Array (map, filter, reduce) e requisições com Fetch API (async/await).";
            textoProjeto = "Construa um buscador de CEP ou previsão do tempo consumindo uma API pública real e exibindo os dados na tela.";
            urlReferencia = "https://developer.mozilla.org/pt-BR/docs/Web/JavaScript";
            textoLink = "🟨 Documentação Oficial JavaScript (MDN Web Docs)";
            corDestaqueLink = "#f7df1e";
            break;

        default:
            saudacaoResultado.textContent = `Olá, ${nome}!`;
            mensagemResultado.textContent = "Por favor, selecione uma área de interesse no menu suspenso para continuarmos.";
            dicaPratica.textContent = "-";
            projetoSugerido.textContent = "-";
            areaResultado.classList.add('erro');
            selectInteresse.focus();
            return;
    }

    saudacaoResultado.textContent = `Olá, ${nome}! Trilha confirmada 🚀`;
    mensagemResultado.textContent = orientacao;
    dicaPratica.textContent = textoDica;
    projetoSugerido.textContent = textoProjeto;
    
    linkEstudo.setAttribute('href', urlReferencia);
    linkEstudo.textContent = textoLink;
    
    if (interesse === 'js') {
        linkEstudo.style.backgroundColor = corDestaqueLink;
        linkEstudo.style.color = "#000";
    } else {
        linkEstudo.style.backgroundColor = corDestaqueLink;
        linkEstudo.style.color = "#fff";
    }
    
    areaResultado.classList.add('sucesso');
    linkEstudo.classList.remove('oculto');
    areaResultado.scrollIntoView({ behavior: 'smooth', block: 'center' });
});

// Alternância de tema
btnTema.addEventListener('click', () => {
    const ehEscuro = document.body.classList.toggle('tema-escuro');
    
    if (ehEscuro) {
        btnTema.textContent = "☀️ Modo Claro";
        btnTema.setAttribute('aria-pressed', 'true');
    } else {
        btnTema.textContent = "🌙 Modo Escuro";
        btnTema.setAttribute('aria-pressed', 'false');
    }
});

// Acessibilidade: tamanho da fonte
btnAumentarFonte.addEventListener('click', () => {
    if (tamanhoFonteAtual < 24) {
        tamanhoFonteAtual += 2;
        htmlRoot.style.setProperty('--tamanho-fonte-base', `${tamanhoFonteAtual}px`);
    }
});

btnDiminuirFonte.addEventListener('click', () => {
    if (tamanhoFonteAtual > 12) {
        tamanhoFonteAtual -= 2;
        htmlRoot.style.setProperty('--tamanho-fonte-base', `${tamanhoFonteAtual}px`);
    }
});